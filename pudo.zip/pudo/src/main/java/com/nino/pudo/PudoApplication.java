package com.nino.pudo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PudoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PudoApplication.class, args);
	}

}
