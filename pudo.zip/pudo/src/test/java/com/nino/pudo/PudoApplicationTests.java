package com.nino.pudo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PudoApplicationTests {

	@Test
	void contextLoads() {
	}

}
